package com.example;

public class Computador extends Jogador{

    @Override
    public boolean Parou() {
        return getPontos() > 16;

    }
    
}

